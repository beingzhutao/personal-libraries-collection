---
layout: default
---

## Phrases

Hello, how are you doing? 
Halo, haw ar you duin

What's your name? 
wot is your naim

I love you.
I lev you

Where do you live? 
Vir du you liv

How old are you?
Haw old ar you

Can you help me? 
Can you hailp mi

Thank you for your help. 
thank you for your hailp

What time is it? 
Wot taiim is it

Have a nice day! 
Haiv naiis dai

See you later. 
Si you laiter

How's it going? 
Haw is it goin

Nice to meet you.
naiis tu mit you

What do you do for a living? 
Wot du you du for e livin

Sorry, I didn't catch that. Can you sai it again? 
Saori ay dident kaich that, can you sai it agen

I'll have a coffee
I will haiw e cofi

Where are you from? 
wier ar you from


## Vernac Example sentences

As demonstrated by the example sentences, it is easy to learn and follow. Each word is broken down into its individual sounds, making it easier for anyone to read and pronounce words accurately. 



The gristst glori in livin laiis not in naiver faolin, but in raisin airi taiim wi faol.  -Nelson Mandela

The greatest glory in living lies not in never falling, but in rising every time we fall. -Nelson Mandela
<br>
The wai tu gait startid is tu kuit taokin and bigen duin. -Walt Disney

The way to get started is to quit talking and begin doing. -Walt Disney
<br>
Your taiim is limitid,so don't waist it livin samwan aios  is laif dont bi trapd  by daogma- wich is livin with the risalts ef ather pipol is thinkin. -Steve Jobs

Your time is limited, so don't waste it living someone else's life. Don't be trapped by dogma – which is living with the results of other people's thinking. -Steve Jobs
<br>


