---
layout: default
---

## Learn

We have organized our language learning resources into several pages: Vocabulary, Grammar, Phonetics, Phrases, and Numbers. And our discord remains the best resource of all.

[Vocabulary](/v/vocabulary)

[Grammar](/v/grammar)

[Phonetics](/v/phonetics)

[Phrases](/v/phrases)

[Numbers](/v/numbers)
