---
layout: default
---

## Info
This website can be ported to other places without modifying the code, just simple settings.yml file
If buy one domain, create change CNAME-delete file to CNAME
I changed version 1.0.0 to  spec.version       = "3.9.0"

blog to news

## Test Page


bin
about siderbar you need to delete this if you change your website /englanto/resources -> /resources <li><a href="/englanto/resources">Resources📖</a></li>



<h3 class="fw-bold border-bottom pb-3 mb-5">About</h3>
<ul>
    <li><a href="/resources">Resources📖</a></li>
    <li>Social media📱
    <ul>
        <li><a href="/test">Test</a></li>
    </ul>
    </li>
    <li><a href="/contact">Contact📧</a></li>
</ul>

<style>
    /* To create a hyperlink in HTML without an underline 
    a {
      text-decoration: none;
      color: blue;
    }*/
    /* Remove bullets from the outer list */
    ul {
      list-style-type: none;
    }
    
    /* Add bullets to the nested list */
    ul ul {
      list-style-type: circle;
    }
    
    /* Indent the nested list */
    ul ul {
      margin-left: 20px;
    }
</style>